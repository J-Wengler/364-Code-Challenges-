class Edge:
    def __init__(self, origin, to, label):
        self.origin = origin
        self.to = to
        self.label = label